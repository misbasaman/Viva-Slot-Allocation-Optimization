<?php
if(isset($_POST['id']))
{
    $connect=new PDO('mysql:host=localhost;dbname=project','root','');
    $query="delete from insertdatetime where id=:id";
    $statement=$connect->prepare($query);
    $statement->execute(
        array(
            ':id'=>$_POST['id']
        )
    );


}




?>