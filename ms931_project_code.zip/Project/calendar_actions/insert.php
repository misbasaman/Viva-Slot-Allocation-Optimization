<?php
session_start();
$sessName = $_SESSION["uname"];

$connect=new PDO('mysql:host=localhost;dbname=project','root','');
$data1 = array();
$data1['info'] = 'misba';


if(isset($_POST["title"]))
{
   $title_catch = $_POST['title'];
    $start_catch=  $_POST['start'];
    $end_catch =  $_POST['end'];

    // query to insert new time slots
    $insert1_query="INSERT into insertdatetime (title,start_event,end_event,markerUserName)VALUES(:set_title,:set_start,:set_end, :set_user)";

    $statement1=$connect->prepare($insert1_query);
    $statement1->execute(
        array(
            ':set_title' => $title_catch,
            ':set_start' => $start_catch,
            ':set_end' => $end_catch,
            ':set_user' => $sessName

        )
    );

}


ob_end_clean();// discard the buffer contents


echo json_encode($data1);// displaying the data

?>