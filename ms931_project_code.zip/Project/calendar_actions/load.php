<?php

session_start();
$userName= $_SESSION["uname"];
//print $userName;

/*$db=mysqli_connect("locahost","root","","testing1");
if(!$db)
{
    print "Couldnot connect to database";
}*/

$connect=new PDO('mysql:host=localhost;dbname=project','root','');

$data=array();//store events table data
$query="select * from insertdatetime  WHERE markerUserName = :user ORDER BY id" ;//fetch data
$statement=$connect->prepare($query);
$statement->bindParam(':user', $userName, PDO::PARAM_STR);
$statement->execute();
$result=$statement->fetchAll();

foreach($result as $row)// foreach works onlyon array $row is value,fetch data from $result
    {
    $data[]=array(
        'id'=>$row["id"],
        'title'=>$row["title"],
        'start'=>$row["start_event"],// [here comes database name] and start is a variable name
        'end' =>$row["end_event"],
        'color' =>'steelblue',
        'textColor' => 'Snow',
        'borderColor' => 'Black'
    );
}



echo json_encode($data); // o/p of this will be [01,"title1",12-02-1092,20-9-2018] display on calendar plugin
?>