<?php


$connect=new PDO('mysql:host=localhost;dbname=project','root','');

if(isset($_POST['id']))
{
    $query="update insertdatetime set title=:title,start_event=:start_event,end_event=:end_event where id=:id";

    $statement=$connect->prepare($query);
    $statement->execute(
      array(// update and display on webpage
          ':title'=>$_POST['title'],
          ':start_event'=>$_POST['start'],
          ':end_event'=>$_POST['end'],
          ':id'=>$_POST['id']
      )
    );


}

/*

$connect=new PDO('mysql:host=localhost;dbname=project','root','');
$data1 = array();
$data1['info'] = 'misba';



if(isset($_POST['id']))
{
    $id_catch1 = $_POST['id'];

    $title_catch1=$_POST['title'];
    $start_catch1=  $_POST['start'];
    $end_catch1 =  $_POST['end'];


// as date is in string type converting it into date type
    $array_of_time1 = array ();
    $start_time1    = strtotime ($start_catch1);
    $end_time1      = strtotime ($end_catch1);

    $thirty_mins1 = 30 * 60;

    while ($start_time1 <= $end_time1)
    {
        $date1 = date("Y-m-d H:i:s", $start_time1);
        $array_of_time1[] = $date;
        $start_time1 += $thirty_mins1;
    }

    $time_len1 = sizeof($array_of_time1);



    $query="update insertdatetime set title=:set_title,start_event=:set_start,end_event=:set_end where id=:set_id";

    for($itr=0; $itr<$time_len1-1; $itr++) {
        $statement = $connect->prepare($query);
    }
    $statement->execute(
        array(// update and display on webpage
            ':set_title'=>$title_catch1,
            ':set_start'=>$array_of_time1[$itr],
            ':set_end'=>$array_of_time1[$itr+1],
            ':set_id'=>$id_catch1
        )
    );


}








ob_end_clean();// discard the buffer contents


echo json_encode($data1);

*/

?>